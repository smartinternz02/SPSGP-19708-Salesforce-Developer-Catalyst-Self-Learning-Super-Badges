# Salesforce-trailhead-Apex-Specialist-step2-Automate-record-creation
#This is 100% working code for SalesForce Apex Specialist Superbatch
